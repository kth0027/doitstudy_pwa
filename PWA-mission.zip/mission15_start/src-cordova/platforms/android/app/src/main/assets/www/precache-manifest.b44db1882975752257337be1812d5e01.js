self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "60f70db266e728294987",
    "url": "css/chunk-vendors.76169836.css"
  },
  {
    "revision": "63a7d78d42c33b94fc7b957524795cac",
    "url": "img/logo.63a7d78d.svg"
  },
  {
    "revision": "b0594d07efce5732a018b74b9efd76c0",
    "url": "index.html"
  },
  {
    "revision": "bbcfcdff7c10aababb37",
    "url": "js/app.bca78daa.js"
  },
  {
    "revision": "60f70db266e728294987",
    "url": "js/chunk-vendors.4ef5e357.js"
  },
  {
    "revision": "b746db01b861b8fa6a723c5c56982fa2",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  }
]);