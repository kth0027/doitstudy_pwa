self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "31a2a527375282292e89",
    "url": "css/chunk-vendors.20f1ebfb.css"
  },
  {
    "revision": "d982910d0eed4853e7005fa2b87eac78",
    "url": "index.html"
  },
  {
    "revision": "68c91671905fc84694e9",
    "url": "js/app.6258fe1b.js"
  },
  {
    "revision": "31a2a527375282292e89",
    "url": "js/chunk-vendors.b72afd12.js"
  },
  {
    "revision": "49c2d119a875ca5aa35d6da9bd097270",
    "url": "manifest.json"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "robots.txt"
  }
]);